<?php

namespace App\Http\Controllers\ListMaster;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests;

class ListController extends Controller
{
    public function list_barang()
    {
        return view('pages/list/list_barang');
    }

    public function list_kategori()
    {
        return view('pages/list/list_kategori');
    }

    public function list_outlet()
    {
        return view('pages/list/list_outlet');
    }

    public function list_pegawai()
    {
        return view('pages/list/list_pegawai');
    }

    public function list_pelanggan()
    {
        return view('pages/list/list_pelanggan');
    }

    public function list_produk()
    {
        return view('pages/list/list_produk');
    }

    public function list_transaksi()
    {
        return view('pages/list/list_transaksi');
    }

    public function list_pembelian()
    {
        return view('pages/list/list_pembelian');
    }

    public function list_pemesanan()
    {
        return view('pages/list/list_pemesanan');
    }

    public function list_penjualan()
    {
        return view('pages/list/list_penjualan');
    }

    public function list_trans_master()
    {
        return view('pages/list/list_trans_master');
    }
}
