<?php

namespace App\Http\Controllers\AddMaster;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests;

class TambahController extends Controller
{
    public function tambah_barang()
    {
        return view('pages/add/tambah_barang');
    }

    public function tambah_kategori()
    {
        return view('pages/add/tambah_kategori');
    }

    public function tambah_outlet()
    {
        return view('pages/add/tambah_outlet');
    }

    public function tambah_pegawai()
    {
        return view('pages/add/tambah_pegawai');
    }

    public function tambah_pelanggan()
    {
        return view('pages/add/tambah_pelanggan');
    }

    public function tambah_transaksi()
    {
        return view('pages/add/tambah_transaksi');
    }

    public function tambah_pembelian()
    {
        return view('pages/add/tambah_pembelian');
    }

    public function tambah_penjualan()
    {
        return view('pages/add/tambah_penjualan');
    }

    public function tambah_pemesanan()
    {
        return view('pages/add/tambah_pemesanan');
    }

    public function tambah_produk()
    {
        return view('pages/add/tambah_produk');
    }
}
