<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


Route::get('/', 'Pos\PosController@index');
// Index
Route::get('/index', 'Pos\PosController@index');
// akun create
Route::get('/signup', 'Pos\PosController@signup');
// akun login
Route::get('/login', 'Pos\PosController@login');
// dashboard
Route::get('/dashboard', 'Pos\PosController@dashboard');
// create master
Route::get('/master', 'Pos\PosController@master');

// add barang
Route::get('/tambah_barang', 'AddMaster\TambahController@tambah_barang');
// add kategori
Route::get('/tambah_kategori', 'AddMaster\TambahController@tambah_kategori');
// add outlet
Route::get('/tambah_outlet', 'AddMaster\TambahController@tambah_outlet');
// add pegawai
Route::get('/tambah_pegawai', 'AddMaster\TambahController@tambah_pegawai');
// add pelanggan
Route::get('/tambah_pelanggan', 'AddMaster\TambahController@tambah_pelanggan');
// add transaksi
Route::get('/tambah_transaksi', 'AddMaster\TambahController@tambah_transaksi');
// add pembelian
Route::get('/tambah_pembelian', 'AddMaster\TambahController@tambah_pembelian');
// add penjualan
Route::get('/tambah_penjualan', 'AddMaster\TambahController@tambah_penjualan');
// add pemesanan
Route::get('/tambah_pemesanan', 'AddMaster\TambahController@tambah_pemesanan');
// add produk
Route::get('/tambah_produk', 'AddMaster\TambahController@tambah_produk');

// list barang
Route::get('/list_barang', 'ListMaster\ListController@list_barang');
// list kategori
Route::get('/list_kategori', 'ListMaster\ListController@list_kategori');
// list outlet
Route::get('/list_outlet', 'ListMaster\ListController@list_outlet');
// list pegawai
Route::get('/list_pegawai', 'ListMaster\ListController@list_pegawai');
// list pelanggan
Route::get('/list_pelanggan', 'ListMaster\ListController@list_pelanggan');
// list transaksi
Route::get('/list_transaksi', 'ListMaster\ListController@list_penjualan');
// list pembelian
Route::get('/list_pembelian', 'ListMaster\ListController@list_pembelian');
// list penjualan
Route::get('/list_penjualan', 'ListMaster\ListController@list_penjualan');
// list pemesanan
Route::get('/list_pemesanan', 'ListMaster\ListController@list_pemesanan');
// list produk
Route::get('/list_produk', 'ListMaster\ListController@list_produk');
// list trans_master
Route::get('/trans_master', 'ListMaster\ListController@list_trans_master');

