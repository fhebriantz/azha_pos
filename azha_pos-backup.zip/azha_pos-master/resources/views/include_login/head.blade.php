	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Blueprint: View Mode Switch" />
    <meta name="keywords" content="view mode, switch, css, style, grid, list, template" />
    <link rel="stylesheet" type="text/css" href="{{ asset('css/bootstrap.min.css')}}"/>
    <link rel="stylesheet" type="text/css" href="{{ asset('css/style.css?v=0.003')}}"/>  
    <link rel="stylesheet" type="text/css" href="{{ asset('css/bootstrap-datetimepicker.min.css')}}">
    <link href="https://fonts.googleapis.com/css?family=Titillium+Web" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="{{ asset('css/jquery.fancybox.min.css')}}">