		<section class="footer-atas">
			
		</section>
		<section class="footer-bawah">
			<div class="container">
				<div class="col-sm-12">
					<div class="row">
						<div class="col-sm-3 footer-1">
							<p>Fitur</p>
							<p>Blog</p>
							<p>Lokasi Kantor</p>
						</div>
						<div class="col-sm-3 footer-2">
							<p>Help</p>
							<p>FAQ</p>
							<p>Referal</p>
						</div>
						<div class="col-sm-3 footer-3">
							<p><strong>Call Center</strong></p>
							<p class="hidesmallhp"><br></p>
							<p><strong>1-500-223</strong></p>
						</div>
						<div class="col-sm-3 footer-4 text-center">
							<p><strong>Follow Us</strong></p>
							<p class="hidesmallhp"><br></p>
							<a href=""><img class="icon-index1" src="{{ asset('image/sm-gp.png')}}" alt=""></a>
							<a href=""><img class="icon-index2" src="{{ asset('image/sm-li.png')}}" alt=""></a>
							<a href=""><img class="icon-index3" src="{{ asset('image/sm-ig.png')}}" alt=""></a>
							<a href=""><img class="icon-index4" src="{{ asset('image/sm-fb.png')}}" alt=""></a>
							<a href=""><img class="icon-index5" src="{{ asset('image/sm-tw.png')}}" alt=""></a>
						</div>
					</div>
				</div>
			</div>
		</section>