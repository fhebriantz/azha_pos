		<section class="header mobilehide">
		    <div class="container ">
		    	<div class="">
			    	<div class="tittle-header">
				    	<h1>Penjualan</h1>
				    	<h1>Terasa Mudah</h1>
				    	<h2>Buat akun Azhapos sekarang dan nikmati</h2>
				    	<h2>kebebasan mengola bisnis Anda dari mana saja</h2>
			    	</div>
			    	<button class="btn my-2 my-sm-0 radius coba-gratis" type="submit">Coba Gratis</button>
			    </div>
			    <div class="fitur-more">
			    	<div class="row" >
			    		<strong>Lihat Semua Fitur</strong>
			    		<a id="btn-more"><img class="viewmore" src="{{ asset('image/down.png')}}" alt=""></a>
			    	</div>
			    </div>
		    </div>
		</section><!-- End of slider content -->

		<section class="mobileshow header-mobile"  >
			<div class="container">
				<div class="">
			    	<div class="tittle-header">
				    	<h1>Penjualan</h1>
				    	<h1>Terasa Mudah</h1>
				    	<h2>Buat akun Azhapos sekarang dan nikmati</h2>
				    	<h2>kebebasan mengola bisnis Anda dari mana saja</h2>
			    	</div>
			    	<button class="btn my-2 my-sm-0 radius coba-gratis" type="submit">Coba Gratis</button>
			    </div>
			</div>
		</section>