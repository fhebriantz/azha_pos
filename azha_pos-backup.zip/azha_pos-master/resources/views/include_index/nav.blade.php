    <!-- nav MOBIle -->
    <div class="testa" id="myTopnav">
      <a href="#home"><img class="mobi-logo-index" src="{{ asset('image/logo1.png')}}" alt=""></a>
      <a class="padding-submen text-center" href="#">Features</a>
      <a class="padding-submen text-center" href="#">Harga</a>
      <a class="padding-submen text-center"  href="#">About</a>
      <a class="padding-submen text-center"  href="{{url('/login')}}">Login</a>
      <a class="padding-submen floee" href="{{url('/signup')}}">
        <button class="btn radius signup-index" type="submit">Sign Up</button>
    </a>
      <a href="javascript:void(0);" class="icon button-collapse" onclick="myFunction()">&#9776;</a>
    </div>

    <!-- nav MOBIle -->