@extends('layouts.sidenav')
@section('title')
    <title>Azhapos - List Barang</title>
@endsection

@section('head')
@endsection

@section('content')

    <div class="main">
        <h1 class="title-size">Buat Data Master</h1>
        <div class="marginmin matop-50 col-md-12">
          <div class="row">
            <div class="col-md-6 col-lg-3">
              <a class="no-under" href="{{url('/tambah_pelanggan')}}">
                <div class="btn-submenu">
                  <img class="image-sub-menu" src="{{ asset('image/user.png')}}">     
                  <p class="no-under sub-title-menu">Pelanggan</p>             
                </div>
              </a>
            </div>
            <div class="col-md-6 col-lg-3">
              <a class="no-under" href="{{url('/tambah_produk')}}">
                <div class="btn-submenu">
                  <img class="image-sub-menu" src="{{ asset('image/package.png')}}">     
                <p class="sub-title-menu">Produk</p>            
                </div>
              </a>
            </div>
            <div class="col-md-6 col-lg-3">
              <a class="no-under" href="{{url('/tambah_kategori')}}">
                <div class="btn-submenu">
                  <img class="image-sub-menu" src="{{ asset('image/file.png')}}">     
                  <p class="sub-title-menu">Kategori</p>              
                </div>
              </a>
            </div>
            <div class="col-md-6 col-lg-3">
              <a href="{{url('/tambah_barang')}}">
                <div class="btn-submenu">
                  <img class="image-sub-menu" src="{{ asset('image/stock.png')}}">     
                  <p class="sub-title-menu">Barang <br>(Stock)</p>               
                </div>
              </a>
            </div>
            <div class="col-md-6 col-lg-3">
              <a href="{{url('/tambah_outlet')}}">
                <div class="btn-submenu">
                  <!-- <img class="image-sub-menu" src="{{ asset('image/#.png')}}">      -->
                  <p class="sub-title-menu">Outlet</p>             
                </div>
              </a>
            </div>
            <div class="col-md-6 col-lg-3">
              <a href="{{url('/tambah_pegawai')}}">
                <div class="btn-submenu">
                  <img class="image-sub-menu" src="{{ asset('image/boss.png')}}">     
                  <p class="sub-title-menu">Pegawai</p>           
                </div>
              </a>
            </div>
            <div class="col-md-6 col-lg-3">
              <a href="{{url('/trans_master')}}">
                <div class="btn-submenu">
                  <img class="image-sub-menu" src="{{ asset('image/transaction.png')}}">     
                  <p class="sub-title-menu">Transaksi</p>           
                </div>
              </a>
            </div>
          </div>
        </div>
    </div>
@endsection
@section('script')

@endsection