@extends('layouts.sidenav')
@section('title')
    <title>Azhapos - List Barang</title>
@endsection

@section('head')
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
@endsection

@section('content')
    <div class="main maen">
          <div class="col-sm-12">
            <div class="row">
              <div class="col-sm-12 col-md-10">
                <div class="row">
                  <div class="col-sm-4 col-xs-4">
                    <div class="row pad-30">
                      <a class="btn  btn-trans" href="{{url('/list_pembelian')}}">Transaksi Pembelian</a>
                    </div>
                  </div>
                  <div class="col-sm-4 col-xs-4">
                    <div class="row pad-30">
                      <a  class="btn btn-trans" href="{{url('/list_penjualan')}}">Transaksi Penjualan</a>
                    </div>
                  </div>
                  <div class="col-sm-4 col-xs-4">
                    <div class="row pad-30">
                      <a class="btn  btn-trans" href="{{url('/list_pemesanan')}}">Transaksi Pemesanan</a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div class="tab-content">
            <div id="home" class="tab-pane fade in active">
              <h3 class="matop-80">Transaksi Penjualan</h3>
              <div class="col-sm-12 data-pelanggan" style="padding-right: 30px; padding-left: 0px;">
                <table class="table text-center" id=""  width="100%" cellspacing="0">
                    <thead class="text-center" id="">
                      <tr >
                          <th class="text-center dx1 mobilehide-list">No.Transaksi</th>
                          <th class="text-center dx2">Barang</th>
                          <th class="text-center dx3 mobilehide-list tabhide-list">Kode</th>
                          <th class="text-center dx4 hide-list">Harga</th>
                          <th class="text-center dx5">Tanggal</th>
                          <th class="text-center dx6">Tindakan</th>
                      </tr>
                    </thead>

                    <tbody class="text-center" id="">
                      <tr>
                        <td class="padding-td mobilehide-list">0001</td>
                        <td class="padding-td">Cincin Berlian</td>
                        <td class="padding-td mobilehide-list tabhide-list">1512</td>
                        <td class="padding-td hide-list">Rp. 25.000.000</td>
                        <td class="padding-td">25 Februari 2018</td>
                        <td class="padding-td set-up">
                          <a data-fancybox data-src="#expand1" href="javascript:;">
                            <button class="btn btn-margin btn-expand">Detail</button>
                          </a>
                          <a class="btn btn-action marginright btn-pencil-list" href=""><img class="pencil-list" src="{{ asset('image/pencil.png')}}" alt=""></a>
                          <a class="btn btn-action marginright btn-trash-list" href=""><img class="trash-list" src="{{ asset('image/trash.png')}}" alt=""></a>

                          <!-- start popup -->
                            <div class="div-expand" id="expand1">
                              <div class="title-popup">
                                <p class="left-popup">Payment With Detail</p>
                                <p class="right-popup">25 Februari 2018</p>
                                <p class="kode-popup">No. 0001</p>
                                <p class="price-popup">Rp. 25.000.000</p>
                                <p class="price-disc"><strike>Rp. 25.000.000</strike></p>
                              </div>
                              <div class="detail-popup col-sm-12 botom-detail text-center">
                                <div class="row">                               
                                  <div class="iframe"  scrolling="yes">
                                    <!-- Start Expand -->
                                    <div class="kotak-trans">
                                      <table class="marbon table text-center tabel"  width="100%" cellspacing="0">
                                        <thead>
                                          <tr >
                                              <th class="text-center" style="width: 25%;">No Transaksi</th>
                                              <th class="text-center" style="width: 25%">Nama Barang</th>
                                              <th class="text-center" style="width: 25%">Expand</th>
                                              <th class="text-center" style="width: 25%">Harga</th>
                                          </tr>
                                        </thead>

                                        <tbody id="">
                                          <tr>
                                            <td>A0001</td>
                                            <td>Emas Batangan</td>
                                            <td>
                                              <a class="collapsed" href="#desc1-1" id="more" data-toggle="collapse">
                                                <span class="if-collapsed">EXPAND</span>
                                                <span class="if-not-collapsed">COLAPSE</span>
                                              </a>
                                            </td>
                                            <td>Rp. 5.000.000</td>
                                          </tr>
                                        </tbody>
                                    </table>
                                    <div id="desc1-1" class="collapse">
                                      <table class="marbon table text-center" width="100%" cellspacing="0">
                                        <thead id="">
                                          <tr >
                                              <th class="text-left padleft" style="width: 50%;">Keterangan</th>
                                              <th class="text-center" style="width: 25%">Tanggal Transaksi</th>
                                              <th class="text-center" style="width: 25%">Jumlah Barang</th>
                                          </tr>
                                        </thead>

                                        <tbody id="">
                                          <tr>
                                            <td class="text-left padleft">Perum. Graha Raya 2. Jl. Cimanggis No. 90 RT. 03/09 Bogor, Jawa Barat.</td>
                                            <td>17 April 1996</td>
                                            <td>10</td>
                                          </tr>
                                        </tbody>
                                      </table>
                                      <table class="marbon table text-center"  width="100%" cellspacing="0">
                                        <thead id="">
                                          <tr >
                                              <th class="text-left padleft" style="width: 25%;">Diskon</th>
                                              <th class="text-center" style="width: 25%">Sisa Barang</th>
                                              <th class="text-center" style="width: 25%">Payment Type</th>
                                              <th class="text-center" style="width: 25%">Tindakan</th>
                                          </tr>
                                        </thead>

                                        <tbody id="">
                                          <tr>
                                            <td class="text-left padleft">0%</td>
                                            <td>13</td>
                                            <td style="color: rgb(68, 158, 216); font-weight: 600;">Debit</td>
                                            <td>
                                              <div class="cbp-vm-icon cbp-vm-add padds">
                                                  <a class="btn btn-action marginright btn-pencil-list" href=""><img class="pencil-list" src="{{ asset('image/pencil.png')}}" alt=""></a>
                                                  <a class="btn btn-action marginright btn-trash-list" href=""><img class="trash-list" src="{{ asset('image/trash.png')}}" alt=""></a>
                                              </div>
                                            </td>
                                          </tr>
                                        </tbody>
                                      </table>
                                    </div>
                                    </div>
                                    <!-- End Expand -->

                                    <!-- Start Expand -->
                                    <div class="kotak-trans">
                                      <table class="table text-center tabel"  width="100%" cellspacing="0">
                                        <thead>
                                          <tr >
                                              <th class="text-center" style="width: 25%;">No Transaksi</th>
                                              <th class="text-center" style="width: 25%">Nama Barang</th>
                                              <th class="text-center" style="width: 25%">Expand</th>
                                              <th class="text-center" style="width: 25%">Harga</th>
                                          </tr>
                                        </thead>

                                        <tbody id="">
                                          <tr>
                                            <td>A0002</td>
                                            <td>Emas Kiloan</td>
                                            <td>
                                              <a class="collapsed" href="#desc1-2" id="more" data-toggle="collapse">
                                                <span class="if-collapsed">EXPAND</span>
                                                <span class="if-not-collapsed">COLAPSE</span>
                                              </a>
                                            </td>
                                            <td>Rp. 8.000.000</td>
                                          </tr>
                                        </tbody>
                                    </table>
                                    <div id="desc1-2" class="collapse">
                                      <table class="table text-center" width="100%" cellspacing="0">
                                        <thead id="">
                                          <tr >
                                              <th class="text-left padleft" style="width: 50%;">Keterangan</th>
                                              <th class="text-center" style="width: 25%">Tanggal Transaksi</th>
                                              <th class="text-center" style="width: 25%">Jumlah Barang</th>
                                          </tr>
                                        </thead>

                                        <tbody id="">
                                          <tr>
                                            <td class="text-left padleft">Perum. Graha Raya 2. Jl. Cimanggis No. 90 RT. 03/09 Bogor, Jawa Barat.</td>
                                            <td>17 April 1996</td>
                                            <td>10</td>
                                          </tr>
                                        </tbody>
                                      </table>
                                      <table class="table text-center"  width="100%" cellspacing="0">
                                        <thead id="">
                                          <tr >
                                              <th class="text-left padleft" style="width: 25%;">Diskon</th>
                                              <th class="text-center" style="width: 25%">Sisa Barang</th>
                                              <th class="text-center" style="width: 25%">Payment Type</th>
                                              <th class="text-center" style="width: 25%">Tindakan</th>
                                          </tr>
                                        </thead>

                                        <tbody id="">
                                          <tr>
                                            <td class="text-left padleft">0%</td>
                                            <td>13</td>
                                            <td style="color: rgb(68, 158, 216); font-weight: 600;">Debit</td>
                                            <td>
                                              <div class="cbp-vm-icon cbp-vm-add padds">
                                                  <a class="btn btn-action marginright btn-pencil-list" href=""><img class="pencil-list" src="{{ asset('image/pencil.png')}}" alt=""></a>
                                                  <a class="btn btn-action marginright btn-trash-list" href=""><img class="trash-list" src="{{ asset('image/trash.png')}}" alt=""></a>
                                              </div>
                                            </td>
                                          </tr>
                                        </tbody>
                                      </table>
                                    </div>
                                    </div>
                                    <!-- End Expand -->
                                  </div>
                                </div>
                              </div>
                              <div class="col-sm-12" style="margin-top: 20px;">
                                <div class="row">
                                   <a class="btn  text-center btn-margin btn-icon-detail text-left" href=""><img class="icon-detail" src="{{ asset('image/trash.png')}}" alt="">Delete</a>
                                </div>
                              </div>
                            </div>
                            <!-- <a class="btn btn-danger" onclick="$.fancybox.close()">Batal</a> -->
                          <!-- end popup -->
                        </td>
                      </tr>

                      <!-- Baris 2 start -->
                      <tr>
                        <td class="padding-td mobilehide-list">0002</td>
                        <td class="padding-td">Mutiara</td>
                        <td class="padding-td mobilehide-list tabhide-list">1512</td>
                        <td class="padding-td hide-list">Rp. 21.000.000</td>
                        <td class="padding-td">12 Februari 2018</td>
                        <td class="padding-td set-up">
                          <a data-fancybox data-src="#expand2" href="javascript:;">
                            <button class="btn btn-margin btn-expand">Detail</button>
                          </a>
                          <a class="btn btn-action marginright btn-pencil-list" href=""><img class="pencil-list" src="{{ asset('image/pencil.png')}}" alt=""></a>
                          <a class="btn btn-action marginright btn-trash-list" href=""><img class="trash-list" src="{{ asset('image/trash.png')}}" alt=""></a>

                          <!-- start popup -->
                            <div class="div-expand" id="expand2">
                              <div class="title-popup">
                                <p class="left-popup">Payment With Detail</p>
                                <p class="right-popup">25 Februari 2018</p>
                                <p class="kode-popup">No. 0002</p>
                                <p class="price-popup">Rp. 88.000.000</p>
                              </div>
                              <div class="detail-popup col-sm-12 botom-detail text-center">
                                <div class="row">                               
                                  <div class="iframe"  scrolling="yes">
                                    <!-- Start Expand -->
                                    <div class="kotak-trans">
                                      <table class="marbon table text-center tabel"  width="100%" cellspacing="0">
                                        <thead>
                                          <tr >
                                              <th class="text-center" style="width: 25%;">No Transaksi</th>
                                              <th class="text-center" style="width: 25%">Nama Barang</th>
                                              <th class="text-center" style="width: 25%">Expand</th>
                                              <th class="text-center" style="width: 25%">Harga</th>
                                          </tr>
                                        </thead>

                                        <tbody id="">
                                          <tr>
                                            <td>A0001</td>
                                            <td>Mutiara</td>
                                            <td>
                                              <a class="collapsed" href="#desc2-1" id="more" data-toggle="collapse">
                                                <span class="if-collapsed">EXPAND</span>
                                                <span class="if-not-collapsed">COLAPSE</span>
                                              </a>
                                            </td>
                                            <td>Rp. 5.000.000</td>
                                          </tr>
                                        </tbody>
                                    </table>
                                    <div id="desc2-1" class="collapse">
                                      <table class="marbon table text-center" width="100%" cellspacing="0">
                                        <thead id="">
                                          <tr >
                                              <th class="text-left padleft" style="width: 50%;">Keterangan</th>
                                              <th class="text-center" style="width: 25%">Tanggal Transaksi</th>
                                              <th class="text-center" style="width: 25%">Jumlah Barang</th>
                                          </tr>
                                        </thead>

                                        <tbody id="">
                                          <tr>
                                            <td class="text-left padleft">Perum. Graha Raya 2. Jl. Cimanggis No. 90 RT. 03/09 Bogor, Jawa Barat.</td>
                                            <td>17 April 1996</td>
                                            <td>10</td>
                                          </tr>
                                        </tbody>
                                      </table>
                                      <table class="marbon table text-center"  width="100%" cellspacing="0">
                                        <thead id="">
                                          <tr >
                                              <th class="text-left padleft" style="width: 25%;">Diskon</th>
                                              <th class="text-center" style="width: 25%">Sisa Barang</th>
                                              <th class="text-center" style="width: 25%">Payment Type</th>
                                              <th class="text-center" style="width: 25%">Tindakan</th>
                                          </tr>
                                        </thead>

                                        <tbody id="">
                                          <tr>
                                            <td class="text-left padleft">0%</td>
                                            <td>13</td>
                                            <td style="color: rgb(68, 158, 216); font-weight: 600;">Debit</td>
                                            <td>
                                              <div class="cbp-vm-icon cbp-vm-add padds">
                                                  <a class="btn btn-action marginright btn-pencil-list" href=""><img class="pencil-list" src="{{ asset('image/pencil.png')}}" alt=""></a>
                                                  <a class="btn btn-action marginright btn-trash-list" href=""><img class="trash-list" src="{{ asset('image/trash.png')}}" alt=""></a>
                                              </div>
                                            </td>
                                          </tr>
                                        </tbody>
                                      </table>
                                    </div>
                                    </div>
                                    <!-- End Expand -->

                                    <!-- Start Expand -->
                                    <div class="kotak-trans">
                                      <table class="table text-center tabel"  width="100%" cellspacing="0">
                                        <thead>
                                          <tr >
                                              <th class="text-center" style="width: 25%;">No Transaksi</th>
                                              <th class="text-center" style="width: 25%">Nama Barang</th>
                                              <th class="text-center" style="width: 25%">Expand</th>
                                              <th class="text-center" style="width: 25%">Harga</th>
                                          </tr>
                                        </thead>

                                        <tbody id="">
                                          <tr>
                                            <td>A0002</td>
                                            <td>Emas Kiloan</td>
                                            <td>
                                              <a class="collapsed" href="#desc2-2" id="more" data-toggle="collapse">
                                                <span class="if-collapsed">EXPAND</span>
                                                <span class="if-not-collapsed">COLAPSE</span>
                                              </a>
                                            </td>
                                            <td>Rp. 8.000.000</td>
                                          </tr>
                                        </tbody>
                                    </table>
                                    <div id="desc2-2" class="collapse">
                                      <table class="table text-center" width="100%" cellspacing="0">
                                        <thead id="">
                                          <tr >
                                              <th class="text-left padleft" style="width: 50%;">Keterangan</th>
                                              <th class="text-center" style="width: 25%">Tanggal Transaksi</th>
                                              <th class="text-center" style="width: 25%">Jumlah Barang</th>
                                          </tr>
                                        </thead>

                                        <tbody id="">
                                          <tr>
                                            <td class="text-left padleft">Perum. Graha Raya 2. Jl. Cimanggis No. 90 RT. 03/09 Bogor, Jawa Barat.</td>
                                            <td>17 April 1996</td>
                                            <td>10</td>
                                          </tr>
                                        </tbody>
                                      </table>
                                      <table class="table text-center"  width="100%" cellspacing="0">
                                        <thead id="">
                                          <tr >
                                              <th class="text-left padleft" style="width: 25%;">Diskon</th>
                                              <th class="text-center" style="width: 25%">Sisa Barang</th>
                                              <th class="text-center" style="width: 25%">Payment Type</th>
                                              <th class="text-center" style="width: 25%">Tindakan</th>
                                          </tr>
                                        </thead>

                                        <tbody id="">
                                          <tr>
                                            <td class="text-left padleft">0%</td>
                                            <td>13</td>
                                            <td style="color: rgb(68, 158, 216); font-weight: 600;">Debit</td>
                                            <td>
                                              <div class="cbp-vm-icon cbp-vm-add padds">
                                                  <a class="btn btn-action marginright btn-pencil-list" href=""><img class="pencil-list" src="{{ asset('image/pencil.png')}}" alt=""></a>
                                                  <a class="btn btn-action marginright btn-trash-list" href=""><img class="trash-list" src="{{ asset('image/trash.png')}}" alt=""></a>
                                              </div>
                                            </td>
                                          </tr>
                                        </tbody>
                                      </table>
                                    </div>
                                    </div>
                                    <!-- End Expand -->
                                  </div>
                                </div>
                              </div>
                              <div class="col-sm-12" style="margin-top: 20px;">
                                <div class="row">
                                   <a class="btn  text-center btn-margin btn-icon-detail text-left" href=""><img class="icon-detail" src="{{ asset('image/trash.png')}}" alt="">Delete</a>
                                </div>
                              </div>
                            </div>
                            <!-- <a class="btn btn-danger" onclick="$.fancybox.close()">Batal</a> -->
                          <!-- end popup -->
                        </td>
                      </tr>
                      <!-- Baris 2 End -->
                    </tbody>
                </table>
              </div>
            </div>

            <div id="menu1" class="tab-pane fade in">
              <h3 class="matop-80">Transaksi Pembelian</h3>
              <div class="col-sm-12 data-pelanggan" style="padding-right: 30px; padding-left: 0px;">
                <table class="table text-center" id=""  width="100%" cellspacing="0">
                    <thead class="text-center" id="">
                       <tr >
                          <th class="text-center"  style="width: 7%">No.Transaksi</th>
                          <th class="text-center" style="width: 20%">Barang</th>
                          <th class="text-center" style="width: 9%">Kode</th>
                          <th class="text-center" style="width: 14%">Harga</th>
                          <th class="text-center" style="width: 20%">Tanggal</th>
                          <th class="text-center" style="width: 30%">Tindakan</th>
                      </tr>
                    </thead>

                    <tbody class="text-center" id="">
                      <tr>
                        <td class="padding-td">0003</td>
                        <td class="padding-td">Cincin Mutiara</td>
                        <td class="padding-td">1512</td>
                        <td class="padding-td">Rp. 25.000.000</td>
                        <td class="padding-td">25 Februari 2018</td>
                        <td class="padding-td">
                          <a data-fancybox data-src="#expand3" href="javascript:;">
                            <button class="btn btn-margin btn-expand">Detail</button>
                          </a>
                          <a class="btn btn-action marginright btn-pencil-list" href=""><img class="pencil-list" src="{{ asset('image/pencil.png')}}" alt=""></a>
                          <a class="btn btn-action marginright btn-trash-list" href=""><img class="trash-list" src="{{ asset('image/trash.png')}}" alt=""></a>

                          <!-- start popup -->
                            <div class="div-expand" id="expand3">
                              <div class="title-popup">
                                <p class="left-popup">Payment With Detail</p>
                                <p class="right-popup">25 Februari 2018</p>
                                <p class="kode-popup">No. 0001</p>
                                <p class="price-popup">Rp. 25.000.000</p>
                              </div>
                              <div class="detail-popup">
                                DETAIL PENJUALAN
                              </div>
                              <div class="col-sm-12 row">
                                <div class="row">
                                  <div class="col-sm-12 baris-detail">
                                    <div class="row">
                                      <div class="col-sm-3">
                                        <p class="title-detail">Nama Barang</p>
                                      </div>
                                      <div class="col-sm-9">
                                        <input type="text" class="form-text" readonly="" value="Cincin Mutiara">
                                      </div> 
                                    </div> 
                                  </div>
                                    <div class="col-sm-12 baris-detail">
                                    <div class="row">
                                      <div class="col-sm-3">
                                        <p class="title-detail">Kode Barang</p>
                                      </div>
                                      <div class="col-sm-9">
                                        <input type="text" class="form-text" readonly="" value="38940">
                                      </div> 
                                    </div> 
                                  </div>
                                    <div class="col-sm-12 baris-detail">
                                    <div class="row">
                                      <div class="col-sm-3">
                                        <p class="title-detail">Keterangan</p>
                                      </div>
                                      <div class="col-sm-9">
                                        <input type="hidden" class="form-control" id="desc-prod">
                                        <textarea form="desc-prod" class="textarea-detail form-text" readonly="">Emas diisi dengan uranium dan vibranium dari Wakanda serta taburan serbuk permata</textarea>
                                      </div> 
                                    </div> 
                                  </div>
                                </div>
                              </div>
                              <div class="col-sm-12 botom-detail text-center">
                                <div class="row">
                                  <div class="col-sm-4">
                                    <p class="title-detail">Jumlah Barang</p>
                                    <input type="text" class="form-text text-center title-bottom" value="38940">
                                  </div>
                                  <div class="col-sm-4">
                                    <p class="title-detail">Sisa Barang</p>
                                    <input type="text" class="form-text text-center title-bottom" value="13">
                                    <a class="btn btn-margin btn-icon-detail text-left" href=""><img class="icon-detail" src="{{ asset('image/trash.png')}}" alt="">Delete</a>
                                  </div>
                                  <div class="col-sm-4">
                                    <p class="title-detail">Diskon</p>
                                    <input type="text" class="form-text text-center title-bottom" value="0%">
                                    <a class="btn btn-margin btn-icon-detail text-left" href=""><img class="icon-detail" src="{{ asset('image/pencil.png')}}" alt="">Edit</a>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <!-- <a class="btn btn-danger" onclick="$.fancybox.close()">Batal</a> -->
                          <!-- end popup -->
                        </td>
                      </tr>
                    </tbody>
                </table>
              </div>
            </div>
          </div>
    </div>
@endsection
@section('script')
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
@endsection