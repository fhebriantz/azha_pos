@extends('layouts.sidenav')
@section('title')
    <title>Azhapos - List Barang</title>
@endsection

@section('head')

@endsection

@section('content')
    <div class="main">
        <h2 class="mobile-size mobilehide" style="color: #aaa;"><strong>Master Data Kategori</strong></h2>
        <h2 class="mobile-size mobileshow" style="color: #aaa;"><strong>Master Kategori</strong></h2>
        <div class="col-sm-12 data-pelanggan">
          <table class="table text-center" id=""  width="100%" cellspacing="0">
              <thead class="text-center" id="">
                <tr >
                    <th class="text-left" style="width: 25%">Kode Kategori</th>
                    <th style="width: 25%">Kode Produk</th>
                    <th style="width: 35%">Nama Kategori</th>
                    <th style="width: 15%">Tindakan</th>
                </tr>
              </thead>

              <tbody class="text-center" id="">
            <tr>
              <td class="text-left">0929008</td>
              <td>A1</td>
              <td>Cincin Berlian</td>
              <td>
                <a class="btn btn-action marginright btn-pencil-list" href=""><img class="pencil-list" src="{{ asset('image/pencil.png')}}" alt=""></a>
                        <a class="btn btn-action marginright btn-trash-list" href=""><img class="trash-list" src="{{ asset('image/trash.png')}}" alt=""></a>
              </td>
            </tr>
            <tr>
              <td class="text-left">0929008</td>
              <td>A1</td>
              <td>Cincin Berlian</td>
              <td>
                <a class="btn btn-action marginright btn-pencil-list" href=""><img class="pencil-list" src="{{ asset('image/pencil.png')}}" alt=""></a>
                        <a class="btn btn-action marginright btn-trash-list" href=""><img class="trash-list" src="{{ asset('image/trash.png')}}" alt=""></a>
              </td>
            </tr>
            <tr>
              <td class="text-left">0929008</td>
              <td>A1</td>
              <td>Cincin Berlian</td>
              <td>
                <a class="btn btn-action marginright btn-pencil-list" href=""><img class="pencil-list" src="{{ asset('image/pencil.png')}}" alt=""></a>
                        <a class="btn btn-action marginright btn-trash-list" href=""><img class="trash-list" src="{{ asset('image/trash.png')}}" alt=""></a>
              </td>
            </tr>
            <tr>
              <td class="text-left">0929008</td>
              <td>A1</td>
              <td>Cincin Berlian</td>
              <td>
                <a class="btn btn-action marginright btn-pencil-list" href=""><img class="pencil-list" src="{{ asset('image/pencil.png')}}" alt=""></a>
                        <a class="btn btn-action marginright btn-trash-list" href=""><img class="trash-list" src="{{ asset('image/trash.png')}}" alt=""></a>
              </td>
            </tr>
            <tr>
              <td class="text-left">0929008</td>
              <td>A1</td>
              <td>Cincin Berlian</td>
              <td>
                <a class="btn btn-action marginright btn-pencil-list" href=""><img class="pencil-list" src="{{ asset('image/pencil.png')}}" alt=""></a>
                        <a class="btn btn-action marginright btn-trash-list" href=""><img class="trash-list" src="{{ asset('image/trash.png')}}" alt=""></a>
              </td>
            </tr>
            <tr>
              <td class="text-left">0929008</td>
              <td>A1</td>
              <td>Cincin Berlian</td>
              <td>
                <a class="btn btn-action marginright btn-pencil-list" href=""><img class="pencil-list" src="{{ asset('image/pencil.png')}}" alt=""></a>
                        <a class="btn btn-action marginright btn-trash-list" href=""><img class="trash-list" src="{{ asset('image/trash.png')}}" alt=""></a>
              </td>
            </tr>
            <tr>
              <td class="text-left">0929008</td>
              <td>A1</td>
              <td>Cincin Berlian</td>
              <td>
                <a class="btn btn-action marginright btn-pencil-list" href=""><img class="pencil-list" src="{{ asset('image/pencil.png')}}" alt=""></a>
                        <a class="btn btn-action marginright btn-trash-list" href=""><img class="trash-list" src="{{ asset('image/trash.png')}}" alt=""></a>
              </td>
            </tr>
            <tr>
              <td class="text-left">0929008</td>
              <td>A1</td>
              <td>Cincin Berlian</td>
              <td>
                <a class="btn btn-action marginright btn-pencil-list" href=""><img class="pencil-list" src="{{ asset('image/pencil.png')}}" alt=""></a>
                        <a class="btn btn-action marginright btn-trash-list" href=""><img class="trash-list" src="{{ asset('image/trash.png')}}" alt=""></a>
              </td>
            </tr>
              </tbody>
          </table>
        </div>
    </div>
@endsection
@section('script')

@endsection