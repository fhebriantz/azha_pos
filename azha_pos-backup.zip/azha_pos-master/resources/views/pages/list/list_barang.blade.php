@extends('layouts.sidenav')
@section('title')
    <title>Azhapos - List Barang</title>
@endsection

@section('head')
    <link rel="stylesheet" type="text/css" href="{{ asset('css/default.css')}}" />
    <link rel="stylesheet" type="text/css" href="{{ asset('css/component.css')}}" />
@endsection

@section('content')
    <div class="main">
        <h2 class="mobile-size mobilehide" style="color: #aaa;"><strong>Master Barang (Stock)</strong></h2>
        <h2 class="mobile-size mobileshow" style="color: #aaa;"><strong>Master Barang</strong></h2>
        <div id="cbp-vm" class="cbp-vm-switcher cbp-vm-view-grid">
          <div class="cbp-vm-options">
            <a href="#" class="cbp-vm-icon cbp-vm-grid cbp-vm-selected" data-view="cbp-vm-view-grid">Grid View</a>
            <a href="#" class="cbp-vm-icon cbp-vm-list" data-view="cbp-vm-view-list">List View</a>
          </div>
          <ul>
            <li class="">
              <a class="cbp-vm-image size-box text-center" href="#"><img src="{{ asset('image/kalung.png')}}"></a>
              <h3 class="cbp-vm-title text-center">Cincin Berlian</h3>
              <div class="cbp-vm-price text-center">Rp. 633.980.000</div>
              <div class="cbp-vm-details kodede tablethide text-center">
                Kode Barang: 58956
              </div>
              <div class="cbp-vm-details datete text-center">
                Dibuat Tanggal: 28/09/17
              </div>
              <div class="cbp-vm-details jumjum text-center">
                Jumlah Stock: 7
              </div>
              <div class="cbp-vm-details berber text-center">
                Berat: 24 gr
              </div>
              <div class="cbp-vm-details karat text-center">
                Karat: 24 karat
              </div>
              <div class="cbp-vm-icon cbp-vm-add">
                <a class="btn btn-action marginright btn-pencil-list" href=""><img class="pencil-list" src="{{ asset('image/pencil.png')}}" alt=""></a>
                <a class="btn btn-action marginright btn-trash-list" href=""><img class="trash-list" src="{{ asset('image/trash.png')}}" alt=""></a>
                <a class="btn btn-action marginright" href="">Print Barcode</a>
              </div>
            </li>
            <li class="">
              <a class="cbp-vm-image size-box text-center" href="#"><img src="{{ asset('image/kalung.png')}}"></a>
              <h3 class="cbp-vm-title text-center">Cincin Berlian</h3>
              <div class="cbp-vm-price text-center">Rp. 633.980.000</div>
              <div class="cbp-vm-details kodede tablethide text-center">
                Kode Barang: 58956
              </div>
              <div class="cbp-vm-details datete text-center">
                Dibuat Tanggal: 28/09/17
              </div>
              <div class="cbp-vm-details jumjum text-center">
                Jumlah Stock: 7
              </div>
              <div class="cbp-vm-details berber text-center">
                Berat: 24 gr
              </div>
              <div class="cbp-vm-details karat text-center">
                Karat: 24 karat
              </div>
              <div class="cbp-vm-icon cbp-vm-add">
                <a class="btn btn-action marginright btn-pencil-list" href=""><img class="pencil-list" src="{{ asset('image/pencil.png')}}" alt=""></a>
                <a class="btn btn-action marginright btn-trash-list" href=""><img class="trash-list" src="{{ asset('image/trash.png')}}" alt=""></a>
                <a class="btn btn-action marginright" href="">Print Barcode</a>
              </div>
            </li>
            <li class="">
              <a class="cbp-vm-image size-box text-center" href="#"><img src="{{ asset('image/kalung.png')}}"></a>
              <h3 class="cbp-vm-title text-center">Cincin Berlian</h3>
              <div class="cbp-vm-price text-center">Rp. 633.980.000</div>
              <div class="cbp-vm-details kodede tablethide text-center">
                Kode Barang: 58956
              </div>
              <div class="cbp-vm-details datete text-center">
                Dibuat Tanggal: 28/09/17
              </div>
              <div class="cbp-vm-details jumjum text-center">
                Jumlah Stock: 7
              </div>
              <div class="cbp-vm-details berber text-center">
                Berat: 24 gr
              </div>
              <div class="cbp-vm-details karat text-center">
                Karat: 24 karat
              </div>
              <div class="cbp-vm-icon cbp-vm-add">
                <a class="btn btn-action marginright btn-pencil-list" href=""><img class="pencil-list" src="{{ asset('image/pencil.png')}}" alt=""></a>
                <a class="btn btn-action marginright btn-trash-list" href=""><img class="trash-list" src="{{ asset('image/trash.png')}}" alt=""></a>
                <a class="btn btn-action marginright" href="">Print Barcode</a>
              </div>
            </li>
            <li class="">
              <a class="cbp-vm-image size-box text-center" href="#"><img src="{{ asset('image/kalung.png')}}"></a>
              <h3 class="cbp-vm-title text-center">Cincin Berlian</h3>
              <div class="cbp-vm-price text-center">Rp. 633.980.000</div>
              <div class="cbp-vm-details kodede tablethide text-center">
                Kode Barang: 58956
              </div>
              <div class="cbp-vm-details datete text-center">
                Dibuat Tanggal: 28/09/17
              </div>
              <div class="cbp-vm-details jumjum text-center">
                Jumlah Stock: 7
              </div>
              <div class="cbp-vm-details berber text-center">
                Berat: 24 gr
              </div>
              <div class="cbp-vm-details karat text-center">
                Karat: 24 karat
              </div>
              <div class="cbp-vm-icon cbp-vm-add">
                <a class="btn btn-action marginright btn-pencil-list" href=""><img class="pencil-list" src="{{ asset('image/pencil.png')}}" alt=""></a>
                <a class="btn btn-action marginright btn-trash-list" href=""><img class="trash-list" src="{{ asset('image/trash.png')}}" alt=""></a>
                <a class="btn btn-action marginright" href="">Print Barcode</a>
              </div>
            </li>
            <li class="">
              <a class="cbp-vm-image size-box text-center" href="#"><img src="{{ asset('image/kalung.png')}}"></a>
              <h3 class="cbp-vm-title text-center">Cincin Berlian</h3>
              <div class="cbp-vm-price text-center">Rp. 633.980.000</div>
              <div class="cbp-vm-details kodede tablethide text-center">
                Kode Barang: 58956
              </div>
              <div class="cbp-vm-details datete text-center">
                Dibuat Tanggal: 28/09/17
              </div>
              <div class="cbp-vm-details jumjum text-center">
                Jumlah Stock: 7
              </div>
              <div class="cbp-vm-details berber text-center">
                Berat: 24 gr
              </div>
              <div class="cbp-vm-details karat text-center">
                Karat: 24 karat
              </div>
              <div class="cbp-vm-icon cbp-vm-add">
                <a class="btn btn-action marginright btn-pencil-list" href=""><img class="pencil-list" src="{{ asset('image/pencil.png')}}" alt=""></a>
                <a class="btn btn-action marginright btn-trash-list" href=""><img class="trash-list" src="{{ asset('image/trash.png')}}" alt=""></a>
                <a class="btn btn-action marginright" href="">Print Barcode</a>
              </div>
            </li>
            <li class="">
              <a class="cbp-vm-image size-box text-center" href="#"><img src="{{ asset('image/kalung.png')}}"></a>
              <h3 class="cbp-vm-title text-center">Cincin Berlian</h3>
              <div class="cbp-vm-price text-center">Rp. 633.980.000</div>
              <div class="cbp-vm-details kodede tablethide text-center">
                Kode Barang: 58956
              </div>
              <div class="cbp-vm-details datete text-center">
                Dibuat Tanggal: 28/09/17
              </div>
              <div class="cbp-vm-details jumjum text-center">
                Jumlah Stock: 7
              </div>
              <div class="cbp-vm-details berber text-center">
                Berat: 24 gr
              </div>
              <div class="cbp-vm-details karat text-center">
                Karat: 24 karat
              </div>
              <div class="cbp-vm-icon cbp-vm-add">
                <a class="btn btn-action marginright btn-pencil-list" href=""><img class="pencil-list" src="{{ asset('image/pencil.png')}}" alt=""></a>
                <a class="btn btn-action marginright btn-trash-list" href=""><img class="trash-list" src="{{ asset('image/trash.png')}}" alt=""></a>
                <a class="btn btn-action marginright" href="">Print Barcode</a>
              </div>
            </li>
          </ul>
        </div>
    </div>
@endsection
@section('script')

@endsection