@extends('layouts.sidenav')
@section('title')
    <title>Azhapos - List Barang</title>
@endsection

@section('head')

@endsection

@section('content')
    <div class="main">
        <h2 class="mobile-size mobilehide" style="color: #aaa;"><strong>Master Data Pegawai</strong></h2>
        <h2 class="mobile-size mobileshow" style="color: #aaa;"><strong>Master Pegawai</strong></h2>
        <div class="col-sm-12 data-pelanggan" style="padding-right: 30px; padding-left: 0px;">
          <table class="table text-center" id=""  width="100%" cellspacing="0">
              <thead class="text-center" id="">
                <tr >
                  <th class="mobilehide-list" style="width: 5%">Kode</th>
                    <th class="widthpeg1">Nama</th>
                    <th class="widthpeg2">Alamat</th>
                    <th class="mobilehide-list tabhide-list" style="width: 20%">Email</th>
                    <th class="mobilehide-list tabhide-list" style="width: 15%">Tanggal Lahir</th>
                    <th class="mobilehide-list">No.HP</th>
                    <th class="widthpeg4">Tindakan</th>
                </tr>
              </thead>

              <tbody class="text-center" id="">
            <tr>
              <td class="mobilehide-list">1511</td>
              <td>Lutfi Febrianto</td>
              <td class="text-left">Perum. Graha Raya 2 Jl Cimanggis no.90 RT.30/05 Bogor. Jawa Barat.</td>
              <td class="mobilehide-list tabhide-list">Lutfi.febrianto@gmail.com</td>
              <td class="mobilehide-list tabhide-list">25 Februari 1996</td>
              <td class="mobilehide-list">085718841359</td>
              <td>
                <a class="btn btn-action marginright btn-pencil-list" href=""><img class="pencil-list" src="{{ asset('image/pencil.png')}}" alt=""></a>
                <a class="btn btn-action marginright btn-trash-list" href=""><img class="trash-list" src="{{ asset('image/trash.png')}}" alt=""></a>
              </td>
            </tr>
              </tbody>
          </table>
        </div>
    </div>
    <!-- <div id="chartContainer" style="height: 370px; width: 100%;"></div>
    <button class="btn invisible" id="backButton">< Back</button> -->
  </body>
@endsection
@section('script')

@endsection