@extends('layouts.sidenav')
@section('title')
    <title>Azhapos - Add</title>
@endsection

@section('head')

@endsection

@section('content')
    <div class="main">
        <h2 class="mobile-size" style="color: #aaa;"><strong>Add Outlet</strong></h2>
        <div class="col-sm-12">
          <div class="row">
            <div class="col-md-12 col-lg-6 padding-right">
                <div class="form-group">
                  <div class="row">
                    <label for="kd-brg">Kode Outlet</label>
                    <input type="text" class="form-control" id="kd-brg" placeholder="Product Code">
                  </div>
                </div>
                <div class="form-group">
                  <div class="row">
                    <label for="desc-prod">Lokasi Outlet</label>
                    <input type="hidden" class="form-control" id="desc-prod">
                    <textarea form="desc-prod" class="textarea form-control" placeholder="Description"></textarea>
                  </div>
                </div>
            </div>
            <div class="col-md-12 col-lg-6 padding-right">
                <div class="form-group">
                  <div class="row">
                    <label for="nm-brg">Nama Outlet</label>
                    <input type="text" class="form-control" id="nm-brg" placeholder="Product Name">
                  </div>
                </div>
                <div style="margin-top: 20px">
                  <div class="row">
                    <label>Add Product Photo</label>
                    <a href="" class="btn btn-outline-info" style="width: 100%">Drag Here</a>
                    <p class="text-right" style="width: 100%; font-size: 12px;">anda bisa upload beberapa foto kesini</p>
                    <a href="" class="btn btn-outline-info" style="width: 100%">Tambah Data Barang</a>
                  </div>
                </div>
                </div>
                
            </div>
          </div>
        </div>
    </div>
@endsection
@section('script')

@endsection