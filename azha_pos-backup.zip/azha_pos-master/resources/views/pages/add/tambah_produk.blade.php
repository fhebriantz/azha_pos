<!DOCTYPE html>
@extends('layouts.sidenav')
@section('title')
    <title>Azhapos - Add</title>
@endsection

@section('head')

@endsection

@section('content')
    <div class="main">
        <h2 class="mobile-size" style="color: #aaa;"><strong>Tambah Produk</strong></h1>
        <div class="col-sm-12">
          <div class="row">
            <div class="col-md-12 col-lg-6 padding-right">
                <div class="form-group">
                  <div class="row">
                    <label for="kd">Kode Produk</label>
                    <input type="text" class="form-control" id="kd" placeholder="Product Code">
                  </div>
                </div>
                <div class="form-group">
                  <div class="row">
                    <label for="desc">Deskripsi Produk</label>
                    <input type="hidden" class="form-control" id="desc">
                    <textarea form="almt" class="textarea form-control" placeholder="Description"></textarea>
                  </div>
                </div>
            </div>
            <div class="col-md-12 col-lg-6 padding-right">
                <div class="form-group">
                  <div class="row">
                    <label for="nm_prod">Nama Produk</label>
                    <input type="text" class="form-control" id="nm_prod" placeholder="Your Email">
                  </div>
                </div>
                <div class="row">
                  <a href="" class="btn btn-outline-info" style="width: 100%">Tambah Data Barang</a>      
                  
                </div>
            </div>
          </div>
        </div>
    </div>
@endsection
@section('script')

@endsection