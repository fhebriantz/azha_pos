@extends('layouts.sidenav')
@section('title')
    <title>Azhapos - Add</title>
@endsection

@section('head')

@endsection

@section('content')
    <div class="main">
        <h2 class="mobile-size" style="color: #aaa;"><strong>Add Produk</strong></h2>
        <div class="col-sm-12">
          <div class="row">
            <div class="col-sm-12 padding-right">
                <div class="form-group">
                  <div class="row">
                    <label for="kd-kat">Kode Kategori</label>
                    <input type="text" class="form-control" id="kd-kat" placeholder="Category Code">
                  </div>
                </div>
                <div class="form-group">
                  <div class="row">
                    <label for="kd">Kode Produk</label>
                    <input type="text" class="form-control" id="kd" placeholder="Product Code">
                  </div>
                </div>
                <div class="form-group">
                  <div class="row">
                    <label for="nm_prod">Nama Kategori</label>
                    <input type="text" class="form-control" id="nm_prod" placeholder="Category Name">
                  </div>
                </div>
            </div>
          </div>
          
        </div>
        <div class="col-md-3 padding-button">
          <div class="row">
           <button style="width: 100%" class="btn btn-outline-info">Tambah Data</button>
          </div>
        </div>
    </div>
@endsection
@section('script')

@endsection